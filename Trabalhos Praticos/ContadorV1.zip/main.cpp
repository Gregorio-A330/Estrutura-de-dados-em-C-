#include <iostream>
using namespace std;
int main(){
    int opc, contador=0;
    do {
    cout<<"contador v1"<<endl;
    cout<<"1-incrementa"<<endl;
    cout<<"2-decrementa"<<endl;
    cout<<"3-exibir"<<endl;
    cout<<"4-fim"<<endl;
    cout<<"Selecione: ";
    cin>>opc;
    switch(opc){
        case 1:
            contador++;
            break;
        case 2:
            contador--;
            if(contador>0){
                contador--;
            }
            break;
        case 3:
            cout<<"Valor atual: "<<contador<<endl;
            break;
        case 4:
            cout<<"fim...."<<endl;
            break;
        default:
            cout<<"opcao invalida...."<<endl;
            break;
    }
    }while (opc != 4);
    return 0;
}
